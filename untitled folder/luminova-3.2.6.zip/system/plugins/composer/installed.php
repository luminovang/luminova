<?php return array(
    'root' => array(
        'name' => 'luminovang/luminova',
        'pretty_version' => 'dev-main',
        'version' => 'dev-main',
        'reference' => 'b7ccb36c999cc1d486d817e3b06f7babd067021d',
        'type' => 'project',
        'install_path' => __DIR__ . '/../../../',
        'aliases' => array(),
        'dev' => false,
    ),
    'versions' => array(
        'luminovang/luminova' => array(
            'pretty_version' => 'dev-main',
            'version' => 'dev-main',
            'reference' => 'b7ccb36c999cc1d486d817e3b06f7babd067021d',
            'type' => 'project',
            'install_path' => __DIR__ . '/../../../',
            'aliases' => array(),
            'dev_requirement' => false,
        ),
        'psr/log' => array(
            'pretty_version' => '1.1.4',
            'version' => '1.1.4.0',
            'reference' => 'd49695b909c3b7628b6289db5479a1c204601f11',
            'type' => 'library',
            'install_path' => __DIR__ . '/../psr/log',
            'aliases' => array(),
            'dev_requirement' => false,
        ),
    ),
);
