<?php
/** @var \Luminova\Routing\Router $router */
/** @var \App\Application $app */

$router->get('/', 'Welcome::home');
