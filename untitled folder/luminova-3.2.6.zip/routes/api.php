<?php
/** @var \Luminova\Routing\Router $router */
/** @var \App\Application $app */

$router->post('/info', 'DemoRequest::info');
