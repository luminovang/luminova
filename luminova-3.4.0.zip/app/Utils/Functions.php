<?php 
/**
 * Luminova Framework
 *
 * @package Luminova
 * @author Ujah Chigozie Peter
 * @copyright (c) Nanoblock Technology Ltd
 * @license See LICENSE file
 */
namespace App\Utils;

use \Luminova\Core\CoreFunction;

class Functions extends CoreFunction
{
    // Add more custom methods
}