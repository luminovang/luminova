<?php 
/**
 * Luminova Framework
 *
 * @package Luminova
 * @author Ujah Chigozie Peter
 * @copyright (c) Nanoblock Technology Ltd
 * @license See LICENSE file
 */

return [
    'alias' => [
        //'Foo' => 'SomeClass\ExampleFoo',
    ],
    'psr-4' => [
       //'Example\MyNamespace'    => '/example/MyClass/',
    ]
];