<?php 
/**
 * Luminova Framework Cron job scheduler for managing scheduled tasks.
 *
 * @package Luminova
 * @author Ujah Chigozie Peter
 * @copyright (c) Nanoblock Technology Ltd
 * @license See LICENSE file
 */
namespace App\Config;

use \Luminova\Core\CoreCronTasks;

final class Cron extends CoreCronTasks
{
    /**
     * Schedule the task for execution.
     */
    protected function schedule(): void 
    {
       /**
         * $this->service('\App\Controllers\ExampleCommand::fooMethod')
         *   ->seconds(5)
         *   ->log(root('/writeable/log/') . 'cron.log');
         */
    }
}
