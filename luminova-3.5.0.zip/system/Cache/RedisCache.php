<?php 
/**
 * Luminova Framework redis extension class.
 *
 * @package Luminova
 * @author Ujah Chigozie Peter
 * @copyright (c) Nanoblock Technology Ltd
 * @license See LICENSE file
 * @link https://luminova.ng
 */
namespace Luminova\Cache;

use \Luminova\Base\BaseCache;
use \Luminova\Time\Timestamp;
use \Luminova\Logger\Logger;
use \Luminova\Exceptions\CacheException;
use Redis;
use \DateTimeInterface;
use \DateInterval;
use \Exception;

final class RedisCache
{
    public function __construct(?string $storage = null) {}

    public static function getInstance(?string $storage = null): static 
    {
        if (self::$instance === null) {
            self::$instance = new static($storage);
        }
        return self::$instance;
    }
}